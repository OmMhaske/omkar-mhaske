package com.jspiders.Musicplayer1;



import java.util.Scanner;

public class MusicPlayerMain {
	static MusicPlayerMain m1 = new MusicPlayerMain();
	static boolean loop= true;
	static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		while (loop) {
			try {
			m1.musicPlayer();
			}catch(NullPointerException e)
			{
				System.out.println("not selected");
			}
		}
	}
	public void musicPlayer() {
		songOperation1 s1 = new songOperation1();
		System.out.println("Choose one option: \n"
				+ "1.Add/Remove song \n"
				+ "2.Play Songs \n"
				+ "3.Edit Song \n"
				+ "4.Exit");
		
		int choice = scanner.nextInt();
		
		switch (choice) {
		case 1:
			System.out.println("Choose one option: \n"
					+ "1.Add song \n"
					+ "2.Remove Songs \n"
					+ "3.Back");
					
			int choice1 = scanner.nextInt();
			switch (choice1) {
			case 1:
				s1.addSongs();
				break;
				
			case 2:
				System.out.println("Removed");
				break;
           
			case 3:
				break;
			default:
				System.out.println("Invalid");
				break;
			}
			break;
		case 2:
			System.out.println("Choose one option: \n"
					+ "1.Play all song \n"
					+ "2.Play random songs \n"
					+ "3.Select songs to play"
					+ "4.Back");
					
			int choice2 = scanner.nextInt();
			switch (choice2) {
			case 1:
				System.out.println("Play all songs");
				break;
				
			case 2:
				System.out.println("Random play");
				break;
           
			case 3:
				System.out.println("Songs");
				break;
				
			case 4:
				break;
			default:
				System.out.println("Invalid");
				break;
			}
			break;
		case 3:
			System.out.println("Edited Successfully");
			break;
         
		case 4:
			System.out.println("Thank you");
			loop = false;
			break;
			
			default:
				System.out.println("Invalid i/p");
				break;
		}
	}
	public static void musicMenu() {
		// TODO Auto-generated method stub
		
	}

}
